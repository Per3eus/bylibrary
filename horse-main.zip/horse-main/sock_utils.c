#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/select.h>

struct channel_guest_s{
  int socket_fd;
  struct sockaddr_in serv_addr;
};
struct channel_guest_s channel_guest;

#ifdef SUBMIT
void init_socket(char* ip_addr, int port){

  memset(&channel_guest, 0, sizeof(channel_guest));
  channel_guest.socket_fd = socket(AF_INET, SOCK_STREAM, 0);
  if(channel_guest.socket_fd < 0)
    return -1;


  channel_guest.serv_addr.sin_family = AF_INET;
  channel_guest.serv_addr.sin_addr.s_addr = inet_addr(ip_addr);
  channel_guest.serv_addr.sin_port = htons(port);
  int ret = connect(channel_guest.socket_fd, (struct sockaddr*)& channel_guest.serv_addr, sizeof(channel_guest.serv_addr));
  //printf("connect ret=%d, socket_fd=%d,ip_addr=%s\n", ret, channel_guest.socket_fd, ip_addr);

  return ret;
}

void write_buffer(char* buffer){
  write(channel_guest.socket_fd, buffer, strlen(buffer));
}

void read_buffer(char* out_buffer){
  read(channel_guest.socket_fd, out_buffer, 1023);
}

#else
void init_socket(char* ip_addr, int port){

  memset(&channel_guest, 0, sizeof(channel_guest));
  channel_guest.socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
  if(channel_guest.socket_fd < 0)
    return -1;


  channel_guest.serv_addr.sin_family = AF_INET;
  channel_guest.serv_addr.sin_addr.s_addr = inet_addr(ip_addr);
  channel_guest.serv_addr.sin_port = htons(port);

  return 1;
}

void write_buffer(char* buffer){
  sendto(channel_guest.socket_fd, buffer, strlen(buffer), 0, (struct sockaddr*)&channel_guest.serv_addr, sizeof(channel_guest.serv_addr));
}

void read_buffer(char* out_buffer){
  recvfrom(channel_guest.socket_fd, out_buffer, 1023, 0, (struct sockaddr*)&channel_guest.serv_addr, sizeof(channel_guest.serv_addr));
}

#endif

void close_socket(){
  close(channel_guest.socket_fd);
}
