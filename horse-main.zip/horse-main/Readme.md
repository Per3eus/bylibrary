# Horse

## 功能描述

马分为两种模式，本地马和远程马，其中远程马又分为kill版本和no kill版本，为了应对题目禁用kill系统调用。

本地马可实现通防（无法防止orw），杀掉启动的shell进程。

远程马目前只实现flag回传功能，无法执行命令。

需关注进程的cpu限制`ulimit -t`，可能导致马被kill。

终止本地马需要`/tmp/stop`文件（题目用户可访问），等待定时器触发退出。

## 依赖

需放通以下系统调用：

- inotify_init
- inotify_add_watch
- kill（kill版本）
- rt_sigqueueinfo（no kill版本）
- clone
- getdents/getdents64
- open/openat

## 编译

配置`global_var.h`中的变量为实际题目环境。

```c
#define PWN_NAME      "/usr/bin/sleep"

#define FLAG_FILE_PATH "/flag"

#define SERVER_IP_ADDRESS "127.0.0.1"
#define SERVER_PORT 1123
```

```shell
#64bit
make all
#32bit
make CFLAGS+=-m32 all
#submit by horse
make CFLAGS+=-DSUBMIT all
```

